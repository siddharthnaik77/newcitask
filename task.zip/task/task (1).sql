-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2019 at 09:49 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `semesters` int(10) NOT NULL,
  `duration` int(11) NOT NULL,
  `desc` longtext NOT NULL,
  `allocated_school` varchar(100) DEFAULT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '1',
  `is_delete` enum('0','1') NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `semesters`, `duration`, `desc`, `allocated_school`, `is_active`, `is_delete`, `created_date`) VALUES
(1, 'MCA', 2, 2, 'test', '2', '1', '1', '2019-12-04 19:21:43'),
(2, 'Bcom', 4, 5, 'test', NULL, '1', '1', '2019-12-04 19:22:35'),
(3, 'MCAsds', 1, 3, 'test', NULL, '1', '1', '2019-12-04 19:25:56'),
(4, 'Bcom', 1, 1, 'test', NULL, '1', '1', '2019-12-04 19:28:00'),
(5, 'MCA', 1, 1, 'test', '3', '1', '0', '2019-12-04 19:31:48'),
(6, 'BBA', 1, 1, 'test', '2', '1', '0', '2019-12-04 19:32:58'),
(7, 'Bcom', 3, 5, 'sss', '4', '1', '0', '2019-12-04 20:24:53');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(50) NOT NULL,
  `allocated_course` varchar(100) DEFAULT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '1',
  `is_delete` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`school_id`, `school_name`, `school_email`, `address`, `country`, `allocated_course`, `is_active`, `is_delete`, `created_at`) VALUES
(2, 'Sarsawat', 'saraswat@yopmail.com', 'mapusa', 'india', '', '1', '0', '2019-12-05 00:46:41'),
(3, 'Sarsawat', 'saraswat@yopmail.com', 'mapusa', 'india', '1,2', '1', '0', '2019-12-05 00:56:58'),
(4, 'HollyCross', 'holly@yopmail.com', 'mapusa', 'goa', '', '1', '0', '2019-12-05 01:29:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
