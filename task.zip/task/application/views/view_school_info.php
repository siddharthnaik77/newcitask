<div class="container " > 
  <div class="row content">
    <a  href="<?php echo site_url(); ?>"  class="button button-purple mt-12 pull-right">View School List</a> 
     
    <h3>View School Info ||    <?php  if(isset($school_info['school_name'])){echo $school_info['school_name']; }?></h3>
    <hr/>
   
    <label >Name:</label>
      <?php  if(isset($school_info['school_name'])){echo $school_info['school_name']; }?>
      <br/>
    <label>Email address:</label>
      <?php  if(isset($school_info['school_email'])){echo $school_info['school_email'];} ?>
      <br/>
    <label >Contact:</label>
      <?php  if(isset($school_info['address'])){echo $school_info['address'];} ?>
      <br/>
    <label >Country:</label>
      <?php  if(isset($school_info['country'])){echo $school_info['country'];} ?>
      <br/>
      <a href="<?php echo site_url('update-school-info').'/'.$school_info['school_id'];?>" class="button button-blue">Edit</a>
  </div>
</div>