  <div class="container " > 


<div class="row content">

       
          
           
    <a  href="<?php echo site_url('courses'); ?>"  class="button button-purple mt-12 pull-right">View Course List</a> 
     
 <h3>View Course Info ||    <?php  if(isset($course_info['course_name'])){echo $course_info['course_name']; }?></h3>
       
    
     <hr/>
   
   
 
      
    <label >Course Name:</label>
   <?php  if(isset($course_info['course_name'])){echo $course_info['course_name']; }?>

<br/>
    <label>Semesters:</label>
  <?php  if(isset($course_info['semesters'])){echo $course_info['semesters'];} ?>
    
    <br/>
    <label >Durations:</label>
      <?php  if(isset($course_info['duration'])){echo $course_info['duration'];} ?>
    <br/>

  
    <label >Country:</label>
      <?php  if(isset($course_info['desc'])){echo $course_info['desc'];} ?>
    <br/>

          

    <a href="<?php echo site_url('update-course-info').'/'.$course_info['course_id'];?>" class="button button-blue">Edit</a>

   
  
     
   
  </div>
  </div>