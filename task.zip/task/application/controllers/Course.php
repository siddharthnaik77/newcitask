<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Course extends CI_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->model('Course_model','course');
        $this->load->model('School_model','school');
        
    }

    public function index() {

        $this->load->library('pagination');
        $config['per_page'] = 10;
        $page = $this->input->get('page', true);
        $search_data = $this->input->get('search_data', true);
        $total_row = $this->course->getCoursesCount();
        $result['courses_list'] = $this->course->getCourses($config['per_page'],$page,$search_data);
        $result['courses_data'] = [];
        foreach ($result['courses_list'] as $key => $value) {
            $schoolnames='';
            if(!empty($value['allocated_school'])){
                $school_id =explode(',', $value['allocated_school']);
                for ($i=0; $i < count($school_id); $i++) { 
                    $row= $this->school->getSchool($school_id[$i]);
                    $schoolnames .= $row['school_name'].',';
                }
                $schoolsnames=rtrim($schoolnames,',');
                array_push($value, $schoolsnames);        
            }else{
                array_push($value, $schoolnames);
            }
            $result['courses_data'][]= $value;

        }
        $this->load->helper("page");
        $config = paginationDesign($search_data,'course',$total_row);
        $this->pagination->initialize($config);
        $result['pagination'] = $this->pagination->create_links();
        $data['content'] = $this->load->view('course_list', $result, true);
        $this->load->view('master', $data);
    }

    public function store() {
        $this->load->library('form_validation');
        if ($this->form_validation->run('create_course_info_frm') == FALSE) {
            $this->create();
        }else{
            $post_data = $_POST;
            if(!empty($_POST['course_name'])){
                $school=implode(',',$_POST['schools']);
            }else{
                $school='';
            }
            
            $courseData = array('course_name'=>$post_data['course_name'],'semesters'=>$post_data['semesters'],'duration'=>$post_data['duration'],'desc'=> $post_data['desc'],'allocated_school'=> $school);
             
            $result = $this->course->addCourse($courseData);  
            if ($result) {
                $this->session->set_flashdata('message', 'Succefully Created Course');
            } else {
                $this->session->set_flashdata('message', "An error occurred while inserting data.");
            }
            redirect('courses');
        }
    }

    public function view($course_id) {
        if ($course_id != '') {
            $row['course_info'] = $this->course->getCourse($course_id);
        }
        $data['content'] = $this->load->view('view_course_info', $row, true);
        $this->load->view('master', $data);
    }

    public function update($course_id) {


        if (isset($_POST['course_id'])) {
            $update_data = $_POST;
            $course_id = $update_data['course_id'];
            unset($update_data['course_id']);
            if(!empty($_POST['schools'])){
                $schools=implode(',',$_POST['schools']);
            }else{
                $schools='';
            }
            
            $courseData = array('course_name'=>$update_data['course_name'],'semesters'=>$update_data['semesters'],'duration'=>$update_data['duration'],'desc'=> $update_data['desc'],'allocated_school'=> $schools);
            $result = $this->course->updateCourse($courseData,$course_id);

            if ($result) {

                $this->session->set_flashdata('message', 'Succefully Updated Course.');
            } else {
                $this->session->set_flashdata('message', 'An error occurred while inserting data');
            }

              redirect('courses');
        }
        if ($course_id != '') {
           $row['course_info'] = $this->course->getCourse($course_id);
           $row['student_list'] = $this->school->getSchools(NULL,NULL,NULL);
        }
        $data['content'] = $this->load->view('update_course_info', $row, true);
        $this->load->view('master', $data);
    }

    public function delete($course_id) {

        if ($course_id != '') {
            $result = $this->course->deleteCourse($course_id);
            if ($result) {
                $this->session->set_flashdata('message', 'Succefully Deleted Student Info.');
            } else {
                $this->session->set_flashdata('message', "An error occurred while inserting data.");
            }
            redirect('/courses');
        }
    }

    public function create(){
        $row['student_list'] = $this->school->getSchools(NULL,NULL,NULL);
        $data['content'] = $this->load->view('course_add',$row, true);
        $this->load->view('master', $data);   
    }

}
