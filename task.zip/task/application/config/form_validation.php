<?php
$config =[
'create_school_info_frm'=>[
							['field'=>'school_name',
						     'label'=>'school name',
							 'rules'=>'required'
							],
							['field'=>'email_address',
						     'label'=>'Email Address',
							 'rules'=>'required|valid_email'
							],
							['field'=>'contact',
						     'label'=>'Contact',
							 'rules'=>'required|numeric'
							],
							['field'=>'country',
						     'label'=>'Country',
							 'rules'=>'required'
							]
						],

'create_course_info_frm'=>[
							['field'=>'course_name',
						     'label'=>'course name',
							 'rules'=>'required'
							],
							['field'=>'semesters',
						     'label'=>'Semester',
							 'rules'=>'required'
							],
							['field'=>'duration',
						     'label'=>'Duration',
							 'rules'=>'required'
							],
							['field'=>'desc',
						     'label'=>'description',
							 'rules'=>'required'
							]
						]
]
?>