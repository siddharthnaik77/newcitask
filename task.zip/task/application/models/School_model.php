<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class School_model extends CI_Model{

	public function getSchoolsCount(){
		$this->db->select('*');
		$this->db->from('schools');
		$this->db->where('is_delete','0');
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function getSchools($limit, $start,$searchData){
		$this->db->select('*');
		$this->db->from('schools');
		$this->db->where('is_delete','0');
		if ($searchData != '') {
			$this->db->like('school_name', $searchData);
        }
		$this->db->limit($limit, $start);
		$query = $this->db->get();
		return $query->result_array();	
	}

	public function getSchool($id){
		$this->db->select('*');
		$this->db->from('schools');
		$this->db->where('school_id',$id);
		$this->db->where('is_delete','0');
		$query = $this->db->get();
		return $query->row_array();	
	}

	public function updateSchool($data,$id){
		$this->db->where('school_id',$id);
		$this->db->update('schools',$data);
		return true;
	}

	public function deleteSchool($id){
		$this->db->set('is_delete','1');
		$this->db->where('school_id',$id);
		$this->db->update('schools');
		return true;
	}

	public function addSchool($data){
		$this->db->insert('schools', $data);
		return true;	
	}

}


?>